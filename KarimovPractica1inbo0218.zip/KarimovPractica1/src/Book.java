import java.lang.*;

public class Book {
    private String name;
    private String author;
    public Book(String n,String a){
        name=n;
        author=a;

    }
    public Book(){
        name="book";
        author="author";
    }
    public void setName(String name){
        this.name=name;

    }
    public void setAuthor(String author){
        this.author=author;
    }
    public String getName(String name){
        return name;
    }
    public String getAuthor(String author){
        return author;
    }
    public String toString(){
        return this.name+" written by "+this.author;
    }



}