import java.lang.*;
public class Library {
    public static void main(String[] args){
        Book b1=new Book("Evgeniy Onegin","Aleksandr Pushkin");
        Book b2=new Book("Master and Margarita","Mikhail Bulgakov");
        System.out.println(b1+", "+b2);
    }


}

